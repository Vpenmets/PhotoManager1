package sysutilities;

import javax.swing.JOptionPane;

public class PhotoProcessingSysTester {
	   
	    	 public static void main(String[] args) {
	    	        // Create a PhotoProcessingSys instance
	    	        PhotoProcessingSys photoProcessingSys = new PhotoProcessingSys("John Doe", "123 Main St", "City", "State", "12345");

	    	        // Test the methods
	    	        System.out.println("Customer Name: " + photoProcessingSys.getCustomerName());
	    	        System.out.println("Customer Address: " + photoProcessingSys.getCustomerAddress().toString());
	    	        System.out.println("Balance: " + photoProcessingSys.getBalance());

	    	        // Perform image transactions
	    	        String transaction1 = photoProcessingSys.imageTransaction("umcp1.jpg", "display", "", true);
	    	        String transaction2 = photoProcessingSys.imageTransaction("umcp1.jpg.jpg", "blackandwhite", "", false);
	    	        String transaction3 = photoProcessingSys.imageTransaction("umcp1.jpg", "selectcolors", " r R G", true);
	    	        String invalidTransaction = photoProcessingSys.imageTransaction("umpc1.jpg", "invalidtask", "", false);

	    	        // Display the transaction log
	    	        System.out.println("Transaction Log:");
	    	        System.out.println(photoProcessingSys.getTransactions());

	    	        // Display the updated balance
	    	        System.out.println("Updated Balance: " + photoProcessingSys.getBalance());

	    	        // Display a message dialog
	    	        JOptionPane.showMessageDialog(null, "Continue");

	    	        // Display the results of transactions
	    	        System.out.println("Transaction 1: " + transaction1);
	    	        System.out.println("Transaction 2: " + transaction2);
	    	        System.out.println("Transaction 3: " + transaction3);
	    	        System.out.println("Invalid Transaction: " + invalidTransaction);
	    	    }
	    	 
	}



