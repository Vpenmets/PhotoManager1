package sysutilities;

public class AddressTester  {
    public static void main(String[] args) {
        // Test constructor with valid parameters
        Address address1 = new Address("123 Main St.", "Cityville", "CA", "12345");
        System.out.println("Address 1: " + address1);

        // Test constructor with default values
        Address address2 = new Address();
        System.out.println("Address 2: " + address2);

        // Test constructor with only street parameter
        Address address3 = new Address("678 Elm Rd.");
        System.out.println("Address 3: " + address3);

        // Test equals method
        System.out.println("Address 1 equals Address 2: " + address1.equals(address2));
        System.out.println("Address 2 equals Address 3: " + address2.equals(address3));

        // Test toString method
        System.out.println("Address 1: " + address1.toString());
        System.out.println("Address 2: " + address2.toString());
        System.out.println("Address 3: " + address3.toString());
    }
}