package sysutilities;

public class Address {
	// Default values
	private static final String DEFAULT_STREET = "8223 Paint Branch Dr.";
	private static final String DEFAULT_CITY = "College Park";
	private static final String DEFAULT_STATE = "MD";
	private static final String DEFAULT_ZIP_CODE = "20742";

	// Instance variables
	private final String street;
	private final String city;
	private final String state;
	private final String zipCode;

	// Constructors
	public Address(String street, String city, String state, String zipCode) {
		// Remove spaces surrounding the parameters
		this.street = street.trim();
		this.city = city.trim();
		this.state = state.trim();

		// Check if the zip code contains only digits
		if (zipCode.matches("\\d+")) {
			this.zipCode = zipCode;
		} else {
			throw new IllegalArgumentException("Invalid Address Argument");
		}
	}

	public Address() {
		this(DEFAULT_STREET, DEFAULT_CITY, DEFAULT_STATE, DEFAULT_ZIP_CODE);
	}

	public Address(Address other) {
		this(other.street, other.city, other.state, other.zipCode);
	}

	public Address(String street) {
		this(street, DEFAULT_CITY, DEFAULT_STATE, DEFAULT_ZIP_CODE);
	}

	// Get methods
	public String getStreet() {
		return street;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZipCode() {
		return zipCode;
	}

	// Equals method
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Address other = (Address) obj;
		return street.equals(other.street) && city.equals(other.city) && state.equals(other.state)
				&& zipCode.equals(other.zipCode);
	}

	// toString method
	public String toString() {
		return street + " " + city + " " + state + " " + zipCode;
	}
}
