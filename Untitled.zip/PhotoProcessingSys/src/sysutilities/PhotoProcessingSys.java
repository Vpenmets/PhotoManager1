package sysutilities;

import javax.swing.JOptionPane;

public class PhotoProcessingSys {
    private String customerName;
    private Address customerAddress;
    private double balance;
    private int transactionCounter;
    private StringBuffer transactionLog;

    public PhotoProcessingSys(String customerName, String street, String city, String state, String zipCode) {
        try {
            customerAddress = new Address(street, city, state, zipCode);
        } catch (IllegalArgumentException e) {
            customerAddress = new Address();
        }
        this.customerName = customerName;
        this.balance = 0.0;
        this.transactionCounter = 0;
        this.transactionLog = new StringBuffer();
    }

    public PhotoProcessingSys() {
        this("NONAME", "", "", "", "");
    }

    public String getCustomerName() {
        return customerName;
    }

    public Address getCustomerAddress() {
        return customerAddress;
    }

    public double getBalance() {
        return balance;
    }

    public String getTransactions() {
     
     return "Image Transactions" +"\n"+ transactionLog.toString();
       
    }

    @Override
    public String toString() {
        return "Customer Name: " + customerName + "\nCustomer Address: " + customerAddress.toString() + "\nBalance: " + balance;
    }

    public String imageTransaction(String imageName, String task, String taskOptions, boolean graphicalMode) {
        transactionCounter++;
        String transactionDescription = "Transaction #" + transactionCounter + ": ";

        if (graphicalMode) {
            PictureManager.graphicalModeOn();
        } else {
            PictureManager.graphicalModeOff();
        }

        String taskResult = "";

        if ("display".equals(task)) {
            taskResult = PictureManager.displayPicture(imageName);
        } else if ("clear".equals(task)) {
            taskResult = PictureManager.clearScreen();
        } else if ("displaylast".equals(task)) {
            taskResult = PictureManager.displayLastPicture();
        } else if ("blackandwhite".equals(task)) {
            taskResult = PictureManager.displayPictureBlackWhitePosterize(imageName, true, false);
        } else if ("posterize".equals(task)) {
            taskResult = PictureManager.displayPictureBlackWhitePosterize(imageName, false, true);
        } else if ("blackandwhiteposterize".equals(task)) {
            taskResult = PictureManager.displayPictureBlackWhitePosterize(imageName, true, true);
        } else if ("selectcolors".equals(task)) {
            String cleanOptions = taskOptions.replaceAll("[^rgbRGB]", "");
            boolean selectRed = cleanOptions.contains("r") || cleanOptions.contains("R");
            boolean selectGreen = cleanOptions.contains("g") || cleanOptions.contains("G");
            boolean selectBlue = cleanOptions.contains("b") || cleanOptions.contains("B");
            taskResult = PictureManager.displayPictureSelectRedGreenBlue(imageName, selectRed, selectGreen, selectBlue);
        } else {
            if (graphicalMode) {
                JOptionPane.showMessageDialog(null, "Continue");
            }
            String invalidMessage = transactionDescription + "Invalid photoProcessing option";
            transactionLog.append(invalidMessage).append("\n");
           
            return "Invalid photoProcessing option";
        }

        double cost = ("selectcolors".equals(task)) ? 2.0 : 1.0;
        balance += cost;
        
        transactionLog.append(transactionDescription).append(taskResult);

        if (graphicalMode) {
            JOptionPane.showMessageDialog(null, "Continue");
        }

        return taskResult;
    }
        
    }

