package javax.swing;

public class JOptionPane {

}
